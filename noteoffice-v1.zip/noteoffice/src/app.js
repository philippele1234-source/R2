/* ===== NOTEOFFICE V1 — APP CONTROLLER ===== */
'use strict';

// ── State ──
let currentApp = 'home';
let currentTab = 'accueil';
let zoom = 100;
let currentFile = null;
let modified = false;

// ── App metadata ──
const APPS = {
  home:    { name: 'Accueil', color: '#2563eb', short: 'Accueil' },
  write:   { name: 'NoteOffice Write',   color: '#2563eb', short: 'W', ext: 'odt' },
  calc:    { name: 'NoteOffice Calc',    color: '#16a34a', short: 'C', ext: 'ods' },
  impress: { name: 'NoteOffice Impress', color: '#ea580c', short: 'I', ext: 'odp' },
  draw:    { name: 'NoteOffice Draw',    color: '#7c3aed', short: 'D', ext: 'odg' },
  base:    { name: 'NoteOffice Base',    color: '#0d9488', short: 'B', ext: 'odb' },
  math:    { name: 'NoteOffice Math',    color: '#ca8a04', short: 'M', ext: 'odf' }
};

// ── Ribbons definition ──
const RIBBONS = {
  accueil: {
    home: `
      <div class="rgroup">
        <div class="rgroup-btns">
          <button class="rbtn" onclick="showNewDoc()"><span class="ri">📄</span><span class="rl">Nouveau</span></button>
          <button class="rbtn" onclick="openFileDialog()"><span class="ri">📂</span><span class="rl">Ouvrir</span></button>
          <button class="rbtn" onclick="saveDoc()"><span class="ri">💾</span><span class="rl">Enreg.</span></button>
        </div>
        <div class="rgroup-label">Fichier</div>
      </div>
      <div class="rgroup">
        <div class="rgroup-btns">
          <button class="rbtn" onclick="openApp('write')"><span class="ri" style="color:#2563eb;font-weight:900">W</span><span class="rl">Write</span></button>
          <button class="rbtn" onclick="openApp('calc')"><span class="ri" style="color:#16a34a;font-weight:900">C</span><span class="rl">Calc</span></button>
          <button class="rbtn" onclick="openApp('impress')"><span class="ri" style="color:#ea580c;font-weight:900">I</span><span class="rl">Impress</span></button>
          <button class="rbtn" onclick="openApp('draw')"><span class="ri" style="color:#7c3aed;font-weight:900">D</span><span class="rl">Draw</span></button>
          <button class="rbtn" onclick="openApp('base')"><span class="ri" style="color:#0d9488;font-weight:900">B</span><span class="rl">Base</span></button>
          <button class="rbtn" onclick="openApp('math')"><span class="ri" style="color:#ca8a04;font-weight:900">M</span><span class="rl">Math</span></button>
        </div>
        <div class="rgroup-label">Applications</div>
      </div>`,
    write: `
      <div class="rgroup">
        <div class="rgroup-btns">
          <button class="rbtn" onclick="saveDoc()"><span class="ri">💾</span><span class="rl">Enreg.</span></button>
          <button class="rbtn" onclick="exportPDF()"><span class="ri">📄</span><span class="rl">PDF</span></button>
          <button class="rbtn" onclick="printDoc()"><span class="ri">🖨</span><span class="rl">Imprimer</span></button>
        </div>
        <div class="rgroup-label">Fichier</div>
      </div>
      <div class="rdivider"></div>
      <div class="rgroup">
        <div class="rgroup-btns">
          <button class="rbtn rbtn-sm" onclick="wCmd('bold')" title="Gras Ctrl+G"><span class="ri"><b>G</b></span><span class="rl">Gras</span></button>
          <button class="rbtn rbtn-sm" onclick="wCmd('italic')" title="Italique Ctrl+I"><span class="ri"><i>I</i></span><span class="rl">Italique</span></button>
          <button class="rbtn rbtn-sm" onclick="wCmd('underline')" title="Souligné Ctrl+S"><span class="ri"><u>S</u></span><span class="rl">Souligné</span></button>
          <button class="rbtn rbtn-sm" onclick="wCmd('strikeThrough')"><span class="ri"><s>ab</s></span><span class="rl">Barré</span></button>
        </div>
        <div class="rgroup-label">Caractère</div>
      </div>
      <div class="rdivider"></div>
      <div class="rgroup">
        <div class="rgroup-btns" style="flex-direction:column;gap:2px">
          <div style="display:flex;gap:2px">
            <select class="rsel" style="width:130px" onchange="wFontName(this.value)" title="Police">
              <option>Times New Roman</option><option>Arial</option>
              <option>Calibri</option><option>Georgia</option>
              <option>Verdana</option><option>Courier New</option>
              <option>Trebuchet MS</option><option>Palatino</option>
            </select>
            <select class="rsel" style="width:50px" onchange="wFontSize(this.value)" title="Taille">
              <option value="1">8</option><option value="2">10</option>
              <option value="3" selected>12</option><option value="4">14</option>
              <option value="5">18</option><option value="6">24</option>
              <option value="7">36</option>
            </select>
          </div>
          <div style="display:flex;gap:2px;align-items:center">
            <button class="rbtn rbtn-sm" onclick="wCmd('justifyLeft')" title="Gauche"><span class="ri">◧</span></button>
            <button class="rbtn rbtn-sm" onclick="wCmd('justifyCenter')" title="Centre"><span class="ri">▥</span></button>
            <button class="rbtn rbtn-sm" onclick="wCmd('justifyRight')" title="Droite"><span class="ri">◨</span></button>
            <button class="rbtn rbtn-sm" onclick="wCmd('justifyFull')" title="Justifier"><span class="ri">▦</span></button>
            <div class="rdivider" style="height:20px"></div>
            <button class="rbtn rbtn-sm" onclick="wCmd('insertUnorderedList')"><span class="ri">≡</span></button>
            <button class="rbtn rbtn-sm" onclick="wCmd('insertOrderedList')"><span class="ri">⒈</span></button>
          </div>
        </div>
        <div class="rgroup-label">Paragraphe</div>
      </div>
      <div class="rdivider"></div>
      <div class="rgroup">
        <div class="rgroup-btns">
          <button class="rbtn rbtn-sm" onclick="wCmd('undo')"><span class="ri">↩</span><span class="rl">Annuler</span></button>
          <button class="rbtn rbtn-sm" onclick="wCmd('redo')"><span class="ri">↪</span><span class="rl">Rétablir</span></button>
        </div>
        <div class="rgroup-label">Historique</div>
      </div>`,
    calc: `
      <div class="rgroup">
        <div class="rgroup-btns">
          <button class="rbtn" onclick="saveDoc()"><span class="ri">💾</span><span class="rl">Enreg.</span></button>
          <button class="rbtn" onclick="calcAddRow()"><span class="ri">➕</span><span class="rl">Ligne</span></button>
          <button class="rbtn" onclick="calcAddCol()"><span class="ri">↔</span><span class="rl">Colonne</span></button>
        </div>
        <div class="rgroup-label">Tableau</div>
      </div>
      <div class="rdivider"></div>
      <div class="rgroup">
        <div class="rgroup-btns">
          <button class="rbtn" onclick="calcInsertFormula('SUM')"><span class="ri">∑</span><span class="rl">Somme</span></button>
          <button class="rbtn" onclick="calcInsertFormula('AVERAGE')"><span class="ri">x̄</span><span class="rl">Moyenne</span></button>
          <button class="rbtn" onclick="calcInsertFormula('COUNT')"><span class="ri">#</span><span class="rl">NB</span></button>
          <button class="rbtn" onclick="calcInsertFormula('MAX')"><span class="ri">⬆</span><span class="rl">Max</span></button>
          <button class="rbtn" onclick="calcInsertFormula('MIN')"><span class="ri">⬇</span><span class="rl">Min</span></button>
        </div>
        <div class="rgroup-label">Fonctions</div>
      </div>`,
    impress: `
      <div class="rgroup">
        <div class="rgroup-btns">
          <button class="rbtn" onclick="impressAddSlide()"><span class="ri">➕</span><span class="rl">Diapo</span></button>
          <button class="rbtn" onclick="impressDeleteSlide()"><span class="ri">🗑</span><span class="rl">Supprimer</span></button>
          <button class="rbtn" onclick="impressStartShow()"><span class="ri">▶</span><span class="rl">Diaporama</span></button>
        </div>
        <div class="rgroup-label">Diapositives</div>
      </div>
      <div class="rdivider"></div>
      <div class="rgroup">
        <div class="rgroup-btns">
          <button class="rbtn rbtn-sm" onclick="impressSetLayout('title')"><span class="ri">📑</span><span class="rl">Titre</span></button>
          <button class="rbtn rbtn-sm" onclick="impressSetLayout('blank')"><span class="ri">⬜</span><span class="rl">Vide</span></button>
          <button class="rbtn rbtn-sm" onclick="impressSetLayout('content')"><span class="ri">📝</span><span class="rl">Contenu</span></button>
        </div>
        <div class="rgroup-label">Disposition</div>
      </div>`,
    draw: `
      <div class="rgroup">
        <div class="rgroup-btns">
          <button class="rbtn rbtn-sm" onclick="drawSetTool('select')"><span class="ri">↖</span><span class="rl">Select.</span></button>
          <button class="rbtn rbtn-sm" onclick="drawSetTool('pencil')"><span class="ri">✏</span><span class="rl">Crayon</span></button>
          <button class="rbtn rbtn-sm" onclick="drawSetTool('line')"><span class="ri">╱</span><span class="rl">Ligne</span></button>
          <button class="rbtn rbtn-sm" onclick="drawSetTool('rect')"><span class="ri">▭</span><span class="rl">Rect.</span></button>
          <button class="rbtn rbtn-sm" onclick="drawSetTool('ellipse')"><span class="ri">○</span><span class="rl">Ellipse</span></button>
          <button class="rbtn rbtn-sm" onclick="drawSetTool('text')"><span class="ri">T</span><span class="rl">Texte</span></button>
        </div>
        <div class="rgroup-label">Outils</div>
      </div>
      <div class="rdivider"></div>
      <div class="rgroup">
        <div class="rgroup-btns">
          <button class="rbtn rbtn-sm" onclick="drawUndo()"><span class="ri">↩</span><span class="rl">Annuler</span></button>
          <button class="rbtn rbtn-sm" onclick="drawClear()"><span class="ri">🗑</span><span class="rl">Effacer</span></button>
          <button class="rbtn rbtn-sm" onclick="saveDoc()"><span class="ri">💾</span><span class="rl">Enreg.</span></button>
        </div>
        <div class="rgroup-label">Actions</div>
      </div>`,
    base: `
      <div class="rgroup">
        <div class="rgroup-btns">
          <button class="rbtn" onclick="baseAddRecord()"><span class="ri">➕</span><span class="rl">Ajouter</span></button>
          <button class="rbtn" onclick="baseDeleteRecord()"><span class="ri">🗑</span><span class="rl">Supprimer</span></button>
          <button class="rbtn" onclick="baseExport()"><span class="ri">📤</span><span class="rl">Exporter</span></button>
        </div>
        <div class="rgroup-label">Données</div>
      </div>`,
    math: `
      <div class="rgroup">
        <div class="rgroup-btns">
          <button class="rbtn rbtn-sm" onclick="mathInsert('\\\\sum')"><span class="ri">∑</span><span class="rl">Somme</span></button>
          <button class="rbtn rbtn-sm" onclick="mathInsert('\\\\int')"><span class="ri">∫</span><span class="rl">Intégrale</span></button>
          <button class="rbtn rbtn-sm" onclick="mathInsert('\\\\sqrt{}')"><span class="ri">√</span><span class="rl">Racine</span></button>
          <button class="rbtn rbtn-sm" onclick="mathInsert('\\\\frac{}{}')"><span class="ri">½</span><span class="rl">Fraction</span></button>
        </div>
        <div class="rgroup-label">Symboles</div>
      </div>`
  }
};

// ── Init ──
document.addEventListener('DOMContentLoaded', () => {
  buildRibbon();
  initWrite();
  initCalc();
  initImpress();
  initDraw();
  initBase();
  initMath();
  setupKeyboardShortcuts();
  // IPC listeners
  if (window.noteoffice) {
    window.noteoffice.onMenu(action => handleMenuAction(action));
    window.noteoffice.onFileOpened(({ path, content }) => {
      currentFile = path;
      toast(`Fichier ouvert : ${path.split(/[\\/]/).pop()}`);
    });
  }
});

// ── Navigation ──
function openScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const sc = document.getElementById('screen-' + id);
  if (sc) sc.classList.add('active');
  document.querySelectorAll('.sb-item').forEach(s => s.classList.remove('active'));
  const si = document.getElementById('si-' + id);
  if (si) si.classList.add('active');
}

function openApp(app) {
  currentApp = app;
  openScreen(app);
  const info = APPS[app];
  document.getElementById('tb-app-name').textContent = '— ' + info.name;
  document.getElementById('tb-filename').textContent = 'Sans titre.' + (info.ext||'') + ' — ' + info.name;
  document.getElementById('sb-app').textContent = info.name;
  document.getElementById('sb-words').textContent = '';
  buildRibbon();
  if (app === 'draw') setTimeout(initDrawCanvas, 50);
}

// ── Ribbon ──
function buildRibbon() {
  const r = document.getElementById('ribbon');
  const tab = RIBBONS[currentTab] || RIBBONS['accueil'];
  const content = tab[currentApp] || tab['home'] || RIBBONS['accueil']['home'];
  const fileGroup = `
    <div class="rgroup">
      <div class="rgroup-btns">
        <button class="rbtn" onclick="showNewDoc()"><span class="ri">📄</span><span class="rl">Nouveau</span></button>
        <button class="rbtn" onclick="openFileDialog()"><span class="ri">📂</span><span class="rl">Ouvrir</span></button>
        <button class="rbtn" onclick="saveDoc()"><span class="ri">💾</span><span class="rl">Enreg.</span></button>
        <button class="rbtn" onclick="printDoc()"><span class="ri">🖨</span><span class="rl">Imprimer</span></button>
      </div>
      <div class="rgroup-label">Fichier</div>
    </div>
    <div class="rdivider"></div>`;
  r.innerHTML = fileGroup + content;
}

function switchTab(tab) {
  currentTab = tab;
  document.querySelectorAll('.rtab').forEach(t => t.classList.remove('active'));
  document.querySelector(`.rtab[data-tab="${tab}"]`).classList.add('active');
  buildRibbon();
}

// ── Zoom ──
function changeZoom(delta) {
  zoom = Math.max(50, Math.min(200, zoom + delta));
  document.getElementById('sb-zoom').textContent = zoom + '%';
  const page = document.getElementById('write-page');
  if (page) {
    page.style.transform = `scale(${zoom / 100})`;
    page.style.transformOrigin = 'top center';
  }
}

// ── Toast ──
function toast(msg, duration = 3000) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), duration);
}

// ── File actions ──
function saveDoc() {
  let content = '', defaultName = 'Sans titre', filters;
  if (currentApp === 'write') {
    content = document.getElementById('write-page')?.innerHTML || '';
    defaultName = 'document.odt';
    filters = [{ name: 'Document ODF', extensions: ['odt'] }, { name: 'HTML', extensions: ['html'] }];
  } else if (currentApp === 'calc') {
    content = JSON.stringify(getCalcData());
    defaultName = 'tableur.ods';
    filters = [{ name: 'Tableur ODF', extensions: ['ods'] }, { name: 'CSV', extensions: ['csv'] }];
  } else {
    content = 'NoteOffice ' + currentApp;
    defaultName = 'fichier.' + (APPS[currentApp]?.ext || 'txt');
    filters = [{ name: 'Fichier NoteOffice', extensions: [APPS[currentApp]?.ext || 'txt'] }];
  }
  if (window.noteoffice) {
    window.noteoffice.saveFile({ content, defaultName, filters }).then(r => {
      if (r.success) { currentFile = r.path; modified = false; toast('✓ Document enregistré'); }
    });
  } else {
    const blob = new Blob([content], { type: 'text/html' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = defaultName;
    a.click();
    toast('✓ Document téléchargé');
  }
}

function exportPDF() {
  if (window.noteoffice?.saveFile) {
    toast('Export PDF en cours...');
  } else {
    window.print();
  }
}
function printDoc() { window.print(); }
function openFileDialog() { toast('Utilisez Fichier → Ouvrir dans le menu natif'); }
function showNewDoc() {
  if (currentApp === 'write') {
    document.getElementById('write-page').innerHTML = '<h2 style="text-align:center;margin-bottom:16px">Sans titre</h2><p>Commencez à saisir votre document ici...</p>';
    currentFile = null; modified = false;
    toast('Nouveau document créé');
  } else if (currentApp !== 'home') {
    toast('Nouveau document ' + APPS[currentApp].name);
  } else {
    openApp('write');
  }
}

function handleMenuAction(action) {
  switch(action) {
    case 'save': saveDoc(); break;
    case 'new': showNewDoc(); break;
    case 'find': toast('Rechercher : Ctrl+F'); break;
    default: toast('Action : ' + action);
  }
}

function menuAction(m) { toast('Menu ' + m + ' — utilisez la barre de menus native (F10)'); }
function winMin() { toast('Réduire (raccourci natif)'); }
function winMax() { toast('Maximiser (raccourci natif)'); }
function winClose() { if(confirm('Quitter NoteOffice ?')) window.close(); }

// ── Keyboard shortcuts ──
function setupKeyboardShortcuts() {
  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey)) {
      switch(e.key.toLowerCase()) {
        case 's': e.preventDefault(); saveDoc(); break;
        case 'p': e.preventDefault(); printDoc(); break;
        case 'n': e.preventDefault(); showNewDoc(); break;
        case '=': case '+': e.preventDefault(); changeZoom(10); break;
        case '-': e.preventDefault(); changeZoom(-10); break;
      }
    }
  });
}

// ─────────────────────────────────────────
//  WRITE
// ─────────────────────────────────────────
function initWrite() {
  const sc = document.getElementById('screen-write');
  sc.innerHTML = `
    <div class="write-toolbar">
      <select class="rsel" style="width:130px" onchange="wFontName(this.value)">
        <option>Times New Roman</option><option>Arial</option><option>Calibri</option>
        <option>Georgia</option><option>Verdana</option><option>Courier New</option>
      </select>
      <select class="rsel" style="width:50px" onchange="wFontSize(this.value)">
        <option value="2">10</option><option value="3" selected>12</option>
        <option value="4">14</option><option value="5">18</option>
        <option value="6">24</option><option value="7">36</option>
      </select>
      <div class="wt-sep"></div>
      <button class="wt-btn" onclick="wCmd('bold')" title="Gras"><b>G</b></button>
      <button class="wt-btn" onclick="wCmd('italic')" title="Italique"><i>I</i></button>
      <button class="wt-btn" onclick="wCmd('underline')" title="Souligné"><u>S</u></button>
      <button class="wt-btn" onclick="wCmd('strikeThrough')"><s>ab</s></button>
      <button class="wt-btn" onclick="wCmd('superscript')">x²</button>
      <button class="wt-btn" onclick="wCmd('subscript')">x₂</button>
      <div class="wt-sep"></div>
      <button class="wt-btn" onclick="wCmd('justifyLeft')" title="Gauche">◧</button>
      <button class="wt-btn" onclick="wCmd('justifyCenter')" title="Centre">▥</button>
      <button class="wt-btn" onclick="wCmd('justifyRight')" title="Droite">◨</button>
      <button class="wt-btn" onclick="wCmd('justifyFull')" title="Justifier">▦</button>
      <div class="wt-sep"></div>
      <button class="wt-btn" onclick="wCmd('insertUnorderedList')">≡</button>
      <button class="wt-btn" onclick="wCmd('insertOrderedList')">⒈</button>
      <button class="wt-btn" onclick="wIndent(1)">→</button>
      <button class="wt-btn" onclick="wIndent(-1)">←</button>
      <div class="wt-sep"></div>
      <button class="wt-btn" onclick="document.getElementById('wt-color').click()" title="Couleur texte">
        <span>A</span><span style="display:block;height:3px;background:#e11d48;border-radius:1px"></span>
      </button>
      <input type="color" id="wt-color" style="display:none" value="#e11d48" onchange="wCmd('foreColor',this.value)">
      <button class="wt-btn" onclick="document.getElementById('wt-bg').click()" title="Surligneur">🖌</button>
      <input type="color" id="wt-bg" style="display:none" value="#fef08a" onchange="wCmd('hiliteColor',this.value)">
      <div class="wt-sep"></div>
      <select class="rsel" style="width:100px" onchange="wHeading(this.value)">
        <option value="p">Normal</option>
        <option value="h1">Titre 1</option>
        <option value="h2">Titre 2</option>
        <option value="h3">Titre 3</option>
        <option value="blockquote">Citation</option>
        <option value="pre">Code</option>
      </select>
      <div class="wt-sep"></div>
      <button class="wt-btn" onclick="wCmd('undo')">↩</button>
      <button class="wt-btn" onclick="wCmd('redo')">↪</button>
      <button class="wt-btn" onclick="insertTable()">⊞</button>
      <button class="wt-btn" onclick="wInsertHR()">—</button>
    </div>
    <div class="write-page-wrap" id="write-page-wrap">
      <div class="write-ruler">
        ${Array.from({length:21},(_,i)=>`<span style="left:${i*10}%">${i*2}</span>`).join('')}
      </div>
      <div class="write-page" id="write-page" contenteditable="true" spellcheck="true" onkeyup="wUpdate()" oninput="wUpdate()">
        <h1 style="text-align:center;margin-bottom:20px;color:#0f172a">Sans titre</h1>
        <p>Commencez à saisir votre document ici. NoteOffice Write supporte la mise en forme complète — <strong>gras</strong>, <em>italique</em>, <u>souligné</u>, listes, titres, tableaux et bien plus.</p>
        <p></p>
        <h2>Introduction</h2>
        <p>Ce document a été créé avec NoteOffice Write V1. Vous pouvez modifier ce texte, appliquer des styles, insérer des tableaux et exporter en PDF ou ODF.</p>
      </div>
    </div>`;
}

function wCmd(cmd, val) {
  document.getElementById('write-page')?.focus();
  document.execCommand(cmd, false, val || null);
  wUpdate();
}
function wFontName(val) { wCmd('fontName', val); }
function wFontSize(val) { wCmd('fontSize', val); }
function wHeading(tag) {
  document.getElementById('write-page')?.focus();
  document.execCommand('formatBlock', false, tag);
}
function wIndent(dir) { wCmd(dir > 0 ? 'indent' : 'outdent'); }
function wInsertHR() {
  document.getElementById('write-page')?.focus();
  document.execCommand('insertHTML', false, '<hr>');
}
function insertTable() {
  const r = parseInt(prompt('Nombre de lignes ?', '3')) || 3;
  const c = parseInt(prompt('Nombre de colonnes ?', '3')) || 3;
  let html = '<table style="border-collapse:collapse;width:100%;margin:12px 0">';
  for(let i=0;i<r;i++){
    html += '<tr>';
    for(let j=0;j<c;j++){
      const tag = i===0?'th':'td';
      html += `<${tag} style="border:1px solid #d1d5db;padding:6px 10px;${i===0?'background:#f1f5f9;font-weight:700':''}">${i===0?'En-tête '+( j+1):'Cellule'}</${tag}>`;
    }
    html += '</tr>';
  }
  html += '</table>';
  document.getElementById('write-page')?.focus();
  document.execCommand('insertHTML', false, html);
}
function wUpdate() {
  const t = document.getElementById('write-page')?.innerText || '';
  const words = t.trim().split(/\s+/).filter(x=>x.length>0).length;
  const chars = t.replace(/\s/g,'').length;
  document.getElementById('sb-words').textContent = `Mots : ${words} · Caractères : ${chars}`;
  modified = true;
}

// ─────────────────────────────────────────
//  CALC
// ─────────────────────────────────────────
const CALC_COLS = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P'];
const CALC_ROWS = 50;
let calcSelected = 'A1';

function initCalc() {
  const sc = document.getElementById('screen-calc');
  sc.innerHTML = `
    <div class="calc-formulabar">
      <div class="calc-ref-box">
        <input class="calc-ref" id="calc-ref" value="A1" readonly>
        <span class="calc-fx">fx</span>
      </div>
      <input class="calc-formula-input" id="calc-formula" placeholder="Valeur ou formule (ex: =A1+B1)" onchange="calcCommitFormula()">
    </div>
    <div class="calc-wrap">
      <table class="calc-table" id="calc-table"></table>
    </div>
    <div class="calc-sheetbar">
      <button class="calc-sheet-tab active">Feuille1</button>
      <button class="calc-sheet-tab">Feuille2</button>
      <button class="calc-sheet-add" onclick="toast('Ajouter une feuille')">+</button>
    </div>`;
  buildCalcTable();
  // Seed data
  const seeds = {
    'A1':'Produit','B1':'Quantité','C1':'Prix unitaire','D1':'Total HT','E1':'TVA 20%','F1':'Total TTC',
    'A2':'Article Alpha','B2':'10','C2':'25.50','D2':'=B2*C2','E2':'=D2*0.2','F2':'=D2+E2',
    'A3':'Article Beta','B3':'5','C3':'49.90','D3':'=B3*C3','E3':'=D3*0.2','F3':'=D3+E3',
    'A4':'Article Gamma','B4':'20','C4':'12.00','D4':'=B4*C4','E4':'=D4*0.2','F4':'=D4+E4',
    'A5':'Article Delta','B5':'3','C5':'199.00','D5':'=B5*C5','E5':'=D5*0.2','F5':'=D5+E5',
    'A7':'TOTAL','D7':'=D2+D3+D4+D5','E7':'=E2+E3+E4+E5','F7':'=F2+F3+F4+F5'
  };
  Object.entries(seeds).forEach(([ref, val]) => {
    const inp = document.getElementById('ci-'+ref);
    if(inp) { inp.value = val; if(val.startsWith('=')) calcEval(ref); }
  });
}

function buildCalcTable() {
  const tbl = document.getElementById('calc-table');
  if(!tbl) return;
  let html = '<thead><tr><th class="calc-corner"></th>';
  CALC_COLS.forEach(c => html += `<th class="calc-col-hdr" id="ch-${c}">${c}</th>`);
  html += '</tr></thead><tbody>';
  for(let r=1;r<=CALC_ROWS;r++){
    html += `<tr><td class="calc-row-hdr" id="rh-${r}">${r}</td>`;
    CALC_COLS.forEach(c=>{
      const ref=c+r;
      html+=`<td class="calc-cell" id="cd-${ref}" onclick="calcSelect('${ref}')"><input type="text" class="calc-input" id="ci-${ref}" onfocus="calcSelect('${ref}')" onkeydown="calcNav(event,'${c}',${r})" onchange="calcCommit('${ref}')" /></td>`;
    });
    html += '</tr>';
  }
  html += '</tbody>';
  tbl.innerHTML = html;
}

function calcSelect(ref) {
  document.querySelectorAll('.calc-cell').forEach(c => c.classList.remove('selected'));
  document.getElementById('cd-'+ref)?.classList.add('selected');
  calcSelected = ref;
  document.getElementById('calc-ref').value = ref;
  const v = document.getElementById('ci-'+ref)?.dataset.raw || document.getElementById('ci-'+ref)?.value || '';
  document.getElementById('calc-formula').value = v;
  const col = ref.match(/[A-Z]+/)[0];
  const row = ref.match(/\d+/)[0];
  document.querySelectorAll('.calc-col-hdr').forEach(h=>h.classList.remove('active'));
  document.querySelectorAll('.calc-row-hdr').forEach(h=>h.classList.remove('active'));
  document.getElementById('ch-'+col)?.classList.add('active');
  document.getElementById('rh-'+row)?.classList.add('active');
}

function calcCommit(ref) {
  const inp = document.getElementById('ci-'+ref);
  if(!inp) return;
  const val = inp.value;
  inp.dataset.raw = val;
  if(val.startsWith('=')) calcEval(ref);
  // Re-eval dependent cells
  for(let r=1;r<=CALC_ROWS;r++) CALC_COLS.forEach(c=>{ const id='ci-'+c+r; const el=document.getElementById(id); if(el?.dataset.raw?.startsWith('=')) calcEval(c+r); });
}

function calcCommitFormula() {
  const inp = document.getElementById('ci-'+calcSelected);
  if(!inp) return;
  inp.value = document.getElementById('calc-formula').value;
  calcCommit(calcSelected);
}

function calcEval(ref) {
  const inp = document.getElementById('ci-'+ref);
  if(!inp) return;
  const raw = inp.dataset.raw || inp.value;
  if(!raw.startsWith('=')) return;
  try {
    let expr = raw.slice(1);
    // Replace cell refs
    expr = expr.replace(/([A-Z]+)(\d+)/g, (_,c,r) => {
      const el = document.getElementById('ci-'+c+r);
      return parseFloat(el?.value)||0;
    });
    // Basic functions
    expr = expr.replace(/SUM\(([^)]+)\)/gi, (_, args) => {
      return args.split(',').reduce((s,a)=>s+(parseFloat(a)||0),0);
    });
    expr = expr.replace(/AVERAGE\(([^)]+)\)/gi, (_, args) => {
      const vals = args.split(',').map(a=>parseFloat(a)||0);
      return vals.reduce((s,v)=>s+v,0)/vals.length;
    });
    expr = expr.replace(/MAX\(([^)]+)\)/gi, (_, args) => Math.max(...args.split(',').map(Number)));
    expr = expr.replace(/MIN\(([^)]+)\)/gi, (_, args) => Math.min(...args.split(',').map(Number)));
    expr = expr.replace(/COUNT\(([^)]+)\)/gi, (_, args) => args.split(',').filter(v=>!isNaN(parseFloat(v))).length);
    const result = Function('"use strict";return (' + expr + ')')();
    inp.value = isNaN(result) ? '#ERR' : Math.round(result*100)/100;
  } catch(e) { inp.value = '#ERR'; }
}

function getCalcData() {
  const data = {};
  for(let r=1;r<=CALC_ROWS;r++) CALC_COLS.forEach(c=>{ const el=document.getElementById('ci-'+c+r); if(el?.value) data[c+r]=el.dataset.raw||el.value; });
  return data;
}

function calcNav(e, col, row) {
  const ci = CALC_COLS.indexOf(col);
  const moves = { Tab:[0,1,true], Enter:[1,0,false], ArrowRight:[0,1,false], ArrowLeft:[0,-1,false], ArrowDown:[1,0,false], ArrowUp:[-1,0,false] };
  const m = moves[e.key];
  if(m) {
    if(m[2]) e.preventDefault();
    const nr = row+m[0], nc = CALC_COLS[ci+m[1]];
    if(nr>=1&&nr<=CALC_ROWS&&nc) { e.preventDefault(); document.getElementById('ci-'+nc+nr)?.focus(); calcSelect(nc+nr); }
  }
}

function calcInsertFormula(fn) {
  const inp = document.getElementById('ci-'+calcSelected);
  if(inp) { inp.value = `=${fn}(`; inp.focus(); calcCommit(calcSelected); }
}
function calcAddRow() { toast('Ligne ajoutée (fonctionnalité V1.1)'); }
function calcAddCol() { toast('Colonne ajoutée (fonctionnalité V1.1)'); }

// ─────────────────────────────────────────
//  IMPRESS
// ─────────────────────────────────────────
let impressSlides = [
  { title:'Titre de la présentation', subtitle:'Sous-titre ou auteur', bg:'#ffffff', layout:'title', notes:'' },
  { title:'Plan de la présentation', subtitle:'• Point 1\n• Point 2\n• Point 3', bg:'#ffffff', layout:'content', notes:'' },
  { title:'Contenu principal', subtitle:'Développement des idées clés', bg:'#f0f4ff', layout:'content', notes:'' },
  { title:'Conclusion', subtitle:'Résumé et prochaines étapes', bg:'#ffffff', layout:'title', notes:'' }
];
let impressCurrent = 0;

function initImpress() {
  const sc = document.getElementById('screen-impress');
  sc.innerHTML = `
    <div class="impress-main">
      <div class="impress-panel-left" id="impress-thumbs"></div>
      <div class="impress-canvas">
        <div class="impress-slide" id="impress-slide">
          <div class="slide-title" id="slide-title" contenteditable="true">Titre</div>
          <div class="slide-subtitle" id="slide-subtitle" contenteditable="true">Sous-titre</div>
        </div>
      </div>
      <div class="impress-panel-right">
        <div class="ip-section">
          <div class="ip-label">Disposition</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
            <div class="ip-layout-btn" onclick="impressSetLayout('title')">🗒 Titre</div>
            <div class="ip-layout-btn" onclick="impressSetLayout('blank')">⬜ Vide</div>
            <div class="ip-layout-btn" onclick="impressSetLayout('content')">📝 Contenu</div>
            <div class="ip-layout-btn" onclick="impressSetLayout('two-col')">◫ 2 colonnes</div>
          </div>
        </div>
        <div class="ip-section">
          <div class="ip-label">Fond</div>
          <div style="display:flex;flex-wrap:wrap;gap:5px">
            ${['#ffffff','#0f1f4b','#1e3a8a','#14532d','#7c2d12','#f1f5f9','#fef9c3','#fce7f3'].map(c=>`<div class="ip-color" style="background:${c};border:${c==='#ffffff'?'1px solid #d1d5db':'none'}" onclick="impressSetBg('${c}')"></div>`).join('')}
          </div>
        </div>
        <div class="ip-section">
          <div class="ip-label">Transition</div>
          <select class="rsel" style="width:100%;height:28px" id="impress-transition">
            <option value="none">Aucune</option>
            <option value="fade">Fondu</option>
            <option value="slide">Glisser</option>
            <option value="zoom">Zoom</option>
          </select>
        </div>
        <div class="ip-section">
          <div class="ip-label">Notes</div>
          <textarea id="impress-notes" style="width:100%;height:80px;border:1px solid #d1d5db;border-radius:4px;font-size:11px;padding:6px;resize:none;font-family:inherit" placeholder="Notes du présentateur..."></textarea>
        </div>
        <button class="btn-primary" style="width:100%;margin-top:4px" onclick="impressStartShow()">▶ Démarrer le diaporama</button>
      </div>
    </div>`;
  renderImpressThumbs();
  loadImpressSlide(0);
}

function renderImpressThumbs() {
  const wrap = document.getElementById('impress-thumbs');
  if(!wrap) return;
  wrap.innerHTML = impressSlides.map((s,i)=>`
    <div class="impress-thumb ${i===impressCurrent?'active':''}" onclick="impressGoTo(${i})">
      <div class="thumb-slide" style="background:${s.bg}">
        <div style="font-size:6px;font-weight:700;color:${s.bg==='#0f1f4b'||s.bg==='#1e3a8a'?'#fff':'#1e293b'};overflow:hidden;max-height:24px">${s.title}</div>
      </div>
      <span class="thumb-num">${i+1}</span>
    </div>`).join('');
}

function loadImpressSlide(idx) {
  impressCurrent = idx;
  const s = impressSlides[idx];
  const slide = document.getElementById('impress-slide');
  if(!slide) return;
  slide.style.background = s.bg;
  const isDark = ['#0f1f4b','#1e3a8a','#14532d','#7c2d12'].includes(s.bg);
  document.getElementById('slide-title').textContent = s.title;
  document.getElementById('slide-title').style.color = isDark ? '#fff' : '#0f172a';
  document.getElementById('slide-subtitle').textContent = s.subtitle;
  document.getElementById('slide-subtitle').style.color = isDark ? '#93c5fd' : '#475569';
  document.getElementById('impress-notes').value = s.notes || '';
  // Save on edit
  document.getElementById('slide-title').oninput = () => { impressSlides[impressCurrent].title = document.getElementById('slide-title').textContent; renderImpressThumbs(); };
  document.getElementById('slide-subtitle').oninput = () => { impressSlides[impressCurrent].subtitle = document.getElementById('slide-subtitle').textContent; };
}

function impressGoTo(idx) { loadImpressSlide(idx); renderImpressThumbs(); }
function impressAddSlide() {
  impressSlides.splice(impressCurrent+1, 0, { title:'Nouvelle diapositive', subtitle:'Contenu ici', bg:'#ffffff', layout:'content', notes:'' });
  impressGoTo(impressCurrent+1);
  renderImpressThumbs();
}
function impressDeleteSlide() {
  if(impressSlides.length===1){toast('Impossible de supprimer la dernière diapositive');return;}
  impressSlides.splice(impressCurrent,1);
  impressGoTo(Math.min(impressCurrent,impressSlides.length-1));
  renderImpressThumbs();
}
function impressSetBg(color) { impressSlides[impressCurrent].bg=color; loadImpressSlide(impressCurrent); renderImpressThumbs(); }
function impressSetLayout(layout) { impressSlides[impressCurrent].layout=layout; toast('Disposition : '+layout); }
function impressStartShow() { toast('Diaporama — appuyez sur F11 pour le plein écran'); }

// ─────────────────────────────────────────
//  DRAW
// ─────────────────────────────────────────
let drawTool='pencil', drawColor='#1e293b', drawFill='#dbeafe';
let drawStroke=2, drawOpacity=1, isDrawing=false;
let drawStartX=0, drawStartY=0, drawSnap=null, drawHistory=[];
let drawCtx=null, drawCanvas=null;

function initDraw() {
  const sc = document.getElementById('screen-draw');
  sc.innerHTML = `
    <div class="draw-main">
      <div class="draw-toolbox">
        <div class="draw-tool-group">
          ${[
            ['select','↖','Sélection'],['pencil','✏','Crayon'],['line','╱','Ligne'],
            ['rect','▭','Rectangle'],['ellipse','○','Ellipse'],['text','T','Texte'],
            ['arrow','→','Flèche']
          ].map(([t,i,l])=>`<button class="draw-tool-btn ${t==='pencil'?'active':''}" id="dt-${t}" onclick="drawSetTool('${t}')" title="${l}"><span>${i}</span><span style="font-size:9px">${l}</span></button>`).join('')}
        </div>
        <hr style="border:none;border-top:1px solid #e2e8f0;margin:6px 0">
        <div class="draw-tool-group">
          <div class="draw-prop-row">
            <span>Trait</span>
            <input type="color" value="#1e293b" onchange="drawColor=this.value" style="width:28px;height:22px;border:none;cursor:pointer;border-radius:3px">
          </div>
          <div class="draw-prop-row">
            <span>Fond</span>
            <input type="color" value="#dbeafe" onchange="drawFill=this.value" style="width:28px;height:22px;border:none;cursor:pointer;border-radius:3px">
          </div>
          <div class="draw-prop-row">
            <span>Épais.</span>
            <input type="range" min="1" max="20" value="2" oninput="drawStroke=+this.value" style="width:60px">
          </div>
          <div class="draw-prop-row">
            <span>Opacité</span>
            <input type="range" min="10" max="100" value="100" oninput="drawOpacity=+this.value/100" style="width:60px">
          </div>
        </div>
        <hr style="border:none;border-top:1px solid #e2e8f0;margin:6px 0">
        <div class="draw-tool-group">
          <div style="font-size:10px;color:#94a3b8;margin-bottom:4px;text-transform:uppercase;letter-spacing:.5px">Formes</div>
          ${[['▭','rect'],['○','ellipse'],['△','triangle'],['★','star'],['→','arrow-shape'],['♦','diamond']].map(([i,s])=>`<button class="draw-shape-btn" onclick="drawInsertShape('${s}')">${i}</button>`).join('')}
        </div>
        <hr style="border:none;border-top:1px solid #e2e8f0;margin:6px 0">
        <button class="draw-tool-btn" onclick="drawUndo()">↩ Annuler</button>
        <button class="draw-tool-btn" onclick="drawClear()">🗑 Effacer</button>
      </div>
      <div class="draw-canvas-wrap" id="draw-canvas-wrap">
        <canvas id="draw-canvas"></canvas>
      </div>
    </div>`;
}

function initDrawCanvas() {
  if(drawCtx) return;
  drawCanvas = document.getElementById('draw-canvas');
  if(!drawCanvas) return;
  const wrap = document.getElementById('draw-canvas-wrap');
  drawCanvas.width = wrap.clientWidth - 40;
  drawCanvas.height = wrap.clientHeight - 40;
  drawCtx = drawCanvas.getContext('2d');
  drawCtx.fillStyle = '#fff';
  drawCtx.fillRect(0,0,drawCanvas.width,drawCanvas.height);

  drawCanvas.addEventListener('mousedown', e => {
    const r = drawCanvas.getBoundingClientRect();
    drawStartX = e.clientX-r.left; drawStartY = e.clientY-r.top;
    isDrawing = true;
    drawSnap = drawCtx.getImageData(0,0,drawCanvas.width,drawCanvas.height);
    if(drawTool==='pencil'){drawCtx.beginPath();drawCtx.moveTo(drawStartX,drawStartY);}
  });

  drawCanvas.addEventListener('mousemove', e => {
    if(!isDrawing) return;
    const r = drawCanvas.getBoundingClientRect();
    const x = e.clientX-r.left, y = e.clientY-r.top;
    drawCtx.globalAlpha = drawOpacity;
    drawCtx.strokeStyle = drawColor;
    drawCtx.fillStyle = drawFill;
    drawCtx.lineWidth = drawStroke;
    drawCtx.lineCap = 'round';
    drawCtx.lineJoin = 'round';
    if(drawTool==='pencil'){drawCtx.lineTo(x,y);drawCtx.stroke();}
    else if(drawSnap){
      drawCtx.putImageData(drawSnap,0,0);
      drawCtx.beginPath();
      if(drawTool==='line'||drawTool==='arrow'){drawCtx.moveTo(drawStartX,drawStartY);drawCtx.lineTo(x,y);drawCtx.stroke();}
      else if(drawTool==='rect'){drawCtx.rect(drawStartX,drawStartY,x-drawStartX,y-drawStartY);drawCtx.fill();drawCtx.stroke();}
      else if(drawTool==='ellipse'){drawCtx.ellipse((drawStartX+x)/2,(drawStartY+y)/2,Math.abs(x-drawStartX)/2,Math.abs(y-drawStartY)/2,0,0,Math.PI*2);drawCtx.fill();drawCtx.stroke();}
    }
  });

  drawCanvas.addEventListener('mouseup', () => {
    isDrawing = false;
    drawHistory.push(drawCtx.getImageData(0,0,drawCanvas.width,drawCanvas.height));
    if(drawHistory.length>50) drawHistory.shift();
  });

  // Touch support
  drawCanvas.addEventListener('touchstart', e => { e.preventDefault(); const t=e.touches[0]; drawCanvas.dispatchEvent(new MouseEvent('mousedown',{clientX:t.clientX,clientY:t.clientY})); });
  drawCanvas.addEventListener('touchmove', e => { e.preventDefault(); const t=e.touches[0]; drawCanvas.dispatchEvent(new MouseEvent('mousemove',{clientX:t.clientX,clientY:t.clientY})); });
  drawCanvas.addEventListener('touchend', () => drawCanvas.dispatchEvent(new MouseEvent('mouseup')));
}

function drawSetTool(t) {
  drawTool = t;
  document.querySelectorAll('.draw-tool-btn').forEach(b=>b.classList.remove('active'));
  document.getElementById('dt-'+t)?.classList.add('active');
}
function drawUndo() {
  if(drawHistory.length>1){drawHistory.pop();drawCtx?.putImageData(drawHistory[drawHistory.length-1],0,0);}
  else if(drawCtx){drawCtx.fillStyle='#fff';drawCtx.fillRect(0,0,drawCanvas.width,drawCanvas.height);}
}
function drawClear() {
  if(drawCtx){drawCtx.fillStyle='#fff';drawCtx.fillRect(0,0,drawCanvas.width,drawCanvas.height);drawHistory=[];}
}
function drawInsertShape(s) {
  if(!drawCtx) return;
  const cx=drawCanvas.width/2, cy=drawCanvas.height/2, w=120, h=90;
  drawCtx.strokeStyle=drawColor; drawCtx.fillStyle=drawFill; drawCtx.lineWidth=drawStroke; drawCtx.globalAlpha=drawOpacity;
  drawCtx.beginPath();
  if(s==='rect'){drawCtx.rect(cx-w/2,cy-h/2,w,h);}
  else if(s==='ellipse'){drawCtx.ellipse(cx,cy,w/2,h/2,0,0,Math.PI*2);}
  else if(s==='triangle'){drawCtx.moveTo(cx,cy-h/2);drawCtx.lineTo(cx+w/2,cy+h/2);drawCtx.lineTo(cx-w/2,cy+h/2);drawCtx.closePath();}
  else if(s==='star'){for(let i=0;i<5;i++){const a=i*72-90;const ar=a*Math.PI/180, ar2=(a+36)*Math.PI/180;drawCtx.lineTo(cx+60*Math.cos(ar),cy+60*Math.sin(ar));drawCtx.lineTo(cx+25*Math.cos(ar2),cy+25*Math.sin(ar2));}drawCtx.closePath();}
  else if(s==='diamond'){drawCtx.moveTo(cx,cy-h/2);drawCtx.lineTo(cx+w/2,cy);drawCtx.lineTo(cx,cy+h/2);drawCtx.lineTo(cx-w/2,cy);drawCtx.closePath();}
  drawCtx.fill(); drawCtx.stroke();
  drawHistory.push(drawCtx.getImageData(0,0,drawCanvas.width,drawCanvas.height));
}

// ─────────────────────────────────────────
//  BASE
// ─────────────────────────────────────────
const BASE_DATA = {
  clients: {
    headers: ['ID','Nom','Prénom','Email','Téléphone','Ville','Date inscription'],
    rows: [
      [1,'Martin','Jean','jean.martin@mail.fr','06 12 34 56 78','Paris','12/01/2024'],
      [2,'Dupont','Marie','m.dupont@mail.fr','07 23 45 67 89','Lyon','15/02/2024'],
      [3,'Bernard','Pierre','p.bernard@mail.fr','06 34 56 78 90','Marseille','03/03/2024'],
      [4,'Petit','Sophie','s.petit@mail.fr','07 45 67 89 01','Bordeaux','22/04/2024'],
      [5,'Robert','Lucas','l.robert@mail.fr','06 56 78 90 12','Toulouse','10/05/2024'],
      [6,'Moreau','Claire','c.moreau@mail.fr','07 67 89 01 23','Nantes','05/06/2024'],
    ]
  },
  commandes: {
    headers: ['N° Cmd','Client ID','Produit','Quantité','Prix Total','Date','Statut'],
    rows: [
      [1001,1,'Produit Alpha',3,'76,50 €','12/03/2025','Livré'],
      [1002,2,'Produit Beta',1,'49,90 €','13/03/2025','En cours'],
      [1003,3,'Produit Gamma',5,'600,00 €','14/03/2025','En attente'],
      [1004,4,'Produit Alpha',2,'51,00 €','15/03/2025','Livré'],
      [1005,5,'Produit Delta',1,'199,00 €','15/03/2025','Annulé'],
    ]
  },
  produits: {
    headers: ['Réf.','Désignation','Catégorie','Prix HT','TVA','Stock','Fournisseur'],
    rows: [
      ['P001','Produit Alpha','Catégorie A','25,50 €','20%',150,'Fournisseur X'],
      ['P002','Produit Beta','Catégorie B','49,90 €','20%',42,'Fournisseur Y'],
      ['P003','Produit Gamma','Catégorie A','120,00 €','20%',18,'Fournisseur X'],
      ['P004','Produit Delta','Catégorie C','199,00 €','20%',7,'Fournisseur Z'],
    ]
  }
};
let baseCurrentTable = 'clients';

function initBase() {
  const sc = document.getElementById('screen-base');
  sc.innerHTML = `
    <div class="base-main">
      <div class="base-sidebar">
        <div class="base-sb-section">
          <div class="base-sb-title">Tables</div>
          ${Object.keys(BASE_DATA).map(t=>`<div class="base-sb-item ${t===baseCurrentTable?'active':''}" id="bsi-${t}" onclick="baseLoadTable('${t}')">📋 ${t.charAt(0).toUpperCase()+t.slice(1)}</div>`).join('')}
        </div>
        <div class="base-sb-section">
          <div class="base-sb-title">Requêtes</div>
          <div class="base-sb-item" onclick="toast('Clients actifs — fonctionnalité V1.1')">🔍 Clients actifs</div>
          <div class="base-sb-item" onclick="toast('Top produits — fonctionnalité V1.1')">🔍 Top produits</div>
        </div>
        <div class="base-sb-section">
          <div class="base-sb-title">Formulaires</div>
          <div class="base-sb-item" onclick="toast('Formulaire Saisie client')">📝 Saisie client</div>
        </div>
        <div class="base-sb-section">
          <div class="base-sb-title">Rapports</div>
          <div class="base-sb-item" onclick="toast('Rapport ventes')">📈 Rapport ventes</div>
        </div>
      </div>
      <div class="base-content">
        <div class="base-toolbar">
          <button class="base-btn" onclick="baseAddRecord()">➕ Ajouter</button>
          <button class="base-btn" onclick="toast('Modifier l\'enregistrement sélectionné')">✏ Modifier</button>
          <button class="base-btn" onclick="baseDeleteRecord()">🗑 Supprimer</button>
          <button class="base-btn" onclick="baseFilter()">🔍 Filtrer</button>
          <button class="base-btn" onclick="baseExport()">📤 Exporter CSV</button>
          <div style="margin-left:auto;display:flex;align-items:center;gap:6px">
            <input class="rinput" style="width:160px" placeholder="Rechercher..." oninput="baseSearch(this.value)" id="base-search">
          </div>
        </div>
        <div class="base-table-wrap">
          <table class="base-table" id="base-table"></table>
        </div>
        <div class="base-statusbar" id="base-status"></div>
      </div>
    </div>`;
  baseLoadTable('clients');
}

function baseLoadTable(name) {
  baseCurrentTable = name;
  document.querySelectorAll('.base-sb-item').forEach(i=>i.classList.remove('active'));
  document.getElementById('bsi-'+name)?.classList.add('active');
  const d = BASE_DATA[name];
  if(!d) return;
  const tbl = document.getElementById('base-table');
  if(!tbl) return;
  tbl.innerHTML = `
    <thead><tr>${d.headers.map(h=>`<th>${h}</th>`).join('')}<th>Actions</th></tr></thead>
    <tbody>${d.rows.map((row,i)=>`
      <tr id="brow-${i}">
        ${row.map(c=>`<td>${c}</td>`).join('')}
        <td style="white-space:nowrap">
          <button class="base-btn-sm" onclick="toast('Modifier ligne ${i+1}')">✏</button>
          <button class="base-btn-sm" onclick="baseDeleteRow(${i})">🗑</button>
        </td>
      </tr>`).join('')}
    </tbody>`;
  document.getElementById('base-status').textContent = `${d.rows.length} enregistrement(s) · Table : ${name}`;
}

function baseAddRecord() {
  const d = BASE_DATA[baseCurrentTable];
  const values = d.headers.map(h => prompt(h+' ?', '') || '');
  d.rows.push(values);
  baseLoadTable(baseCurrentTable);
  toast(`✓ Enregistrement ajouté`);
}
function baseDeleteRow(idx) {
  if(!confirm('Supprimer cet enregistrement ?')) return;
  BASE_DATA[baseCurrentTable].rows.splice(idx,1);
  baseLoadTable(baseCurrentTable);
}
function baseDeleteRecord() { toast('Sélectionnez un enregistrement à supprimer'); }
function baseFilter() { toast('Filtre avancé — fonctionnalité V1.1'); }
function baseSearch(q) {
  const d = BASE_DATA[baseCurrentTable];
  const rows = document.querySelectorAll('#base-table tbody tr');
  rows.forEach((tr,i) => {
    const match = d.rows[i]?.some(c => String(c).toLowerCase().includes(q.toLowerCase()));
    tr.style.display = match||!q ? '' : 'none';
  });
}
function baseExport() {
  const d = BASE_DATA[baseCurrentTable];
  const csv = [d.headers.join(','), ...d.rows.map(r=>r.join(','))].join('\n');
  const blob = new Blob([csv],{type:'text/csv'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = baseCurrentTable+'.csv';
  a.click();
  toast(`✓ Export CSV : ${baseCurrentTable}.csv`);
}

// ─────────────────────────────────────────
//  MATH
// ─────────────────────────────────────────
function initMath() {
  const sc = document.getElementById('screen-math');
  const cats = [
    ['Opérateurs', ['±','×','÷','≠','≈','≤','≥','∝','∓','∑','∏','√','∛','∞','‰','∂']],
    ['Grec minusc.', ['α','β','γ','δ','ε','ζ','η','θ','ι','κ','λ','μ','ν','ξ','π','ρ','σ','τ','υ','φ','χ','ψ','ω']],
    ['Grec majusc.', ['Α','Β','Γ','Δ','Ε','Ζ','Η','Θ','Λ','Μ','Ν','Ξ','Π','Ρ','Σ','Τ','Φ','Χ','Ψ','Ω']],
    ['Intégrales', ['∫','∬','∭','∮','∯','∰','∱','∲','∳']],
    ['Ensembles', ['∈','∉','∋','∌','⊂','⊃','⊆','⊇','∪','∩','∅','∖','△']],
    ['Logique', ['∧','∨','¬','⊕','⊻','∀','∃','∄','⊤','⊥','⊢','⊨']],
    ['Flèches', ['→','←','↔','⇒','⇐','⇔','↑','↓','↕','⇑','⇓','⇕','↗','↖','↘','↙']],
    ['Exposants', ['⁰','¹','²','³','⁴','⁵','⁶','⁷','⁸','⁹','⁺','⁻','⁼','⁽','⁾','ⁿ']],
    ['Indices', ['₀','₁','₂','₃','₄','₅','₆','₇','₈','₉','₊','₋','₌','₍','₎']],
    ['Géométrie', ['∠','∟','⊾','⊿','△','▲','▵','□','▪','⬛','○','●','∥','⊥','≅','∼']],
  ];

  sc.innerHTML = `
    <div class="math-main">
      <div class="math-symbols">
        ${cats.map(([cat,syms])=>`
          <div class="math-cat-title">${cat}</div>
          <div class="math-sym-grid">
            ${syms.map(s=>`<button class="math-sym-btn" onclick="mathInsert('${s}')" title="${s}">${s}</button>`).join('')}
          </div>`).join('')}
      </div>
      <div class="math-editor">
        <div class="math-editor-label">Éditeur de formule :</div>
        <div class="math-templates">
          <button class="math-tpl-btn" onclick="mathTemplate('frac')">a/b</button>
          <button class="math-tpl-btn" onclick="mathTemplate('sqrt')">√a</button>
          <button class="math-tpl-btn" onclick="mathTemplate('sum')">Σ</button>
          <button class="math-tpl-btn" onclick="mathTemplate('int')">∫</button>
          <button class="math-tpl-btn" onclick="mathTemplate('matrix')">Matrice</button>
          <button class="math-tpl-btn" onclick="mathTemplate('limit')">lim</button>
          <button class="math-tpl-btn" onclick="mathTemplate('vec')">vecteur</button>
        </div>
        <textarea id="math-input" class="math-textarea" placeholder="Saisissez votre formule ici…" oninput="mathUpdate()" spellcheck="false">f(x) = ∑ αₙ · xⁿ + ∫₀^∞ e^(-x²) dx</textarea>
        <div class="math-preview-label">Aperçu :</div>
        <div class="math-preview" id="math-preview">f(x) = ∑ αₙ · xⁿ + ∫₀^∞ e^(-x²) dx</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn-primary" onclick="mathCopy()">📋 Copier</button>
          <button class="btn-secondary" onclick="mathInsertInWrite()">📝 Insérer dans Write</button>
          <button class="btn-secondary" onclick="saveDoc()">💾 Enregistrer</button>
          <button class="btn-secondary" onclick="mathClear()">🗑 Effacer</button>
        </div>
      </div>
    </div>`;
}

function mathInsert(sym) {
  const ta = document.getElementById('math-input');
  if(!ta) return;
  const pos = ta.selectionStart;
  ta.value = ta.value.slice(0,pos) + sym + ta.value.slice(pos);
  ta.selectionStart = ta.selectionEnd = pos + sym.length;
  ta.focus();
  mathUpdate();
}
function mathTemplate(t) {
  const templates = {
    frac: 'a/b',
    sqrt: '√(a)',
    sum: '∑ᵢ₌₀ⁿ f(i)',
    int: '∫ₐᵇ f(x) dx',
    matrix: '|a b|\n|c d|',
    limit: 'lim_{x→0} f(x)',
    vec: 'v⃗ = (x, y, z)'
  };
  const ta = document.getElementById('math-input');
  if(ta && templates[t]) { ta.value += (ta.value?'\n':'')+templates[t]; mathUpdate(); }
}
function mathUpdate() {
  const v = document.getElementById('math-input')?.value || '';
  const prev = document.getElementById('math-preview');
  if(prev) prev.textContent = v;
}
function mathCopy() {
  const v = document.getElementById('math-input')?.value || '';
  navigator.clipboard.writeText(v).then(()=>toast('✓ Formule copiée')).catch(()=>toast('Copie manuelle requise'));
}
function mathInsertInWrite() {
  const v = document.getElementById('math-input')?.value || '';
  if(v) {
    openApp('write');
    setTimeout(()=>{ document.getElementById('write-page')?.focus(); document.execCommand('insertHTML',false,`<span style="font-style:italic;color:#1e40af;font-size:1.1em"> ${v} </span>`); },100);
    toast('✓ Formule insérée dans Write');
  }
}
function mathClear() {
  const ta = document.getElementById('math-input');
  if(ta) { ta.value=''; mathUpdate(); }
}
