// ===== NOTEOFFICE V1 — SHELL JS =====
const { ipcRenderer } = require('electron');
let currentApp = 'home', zoom = 100;

// === SPLASH ===
const splashMsgs = ['Initialisation...','Chargement de Write...','Chargement de Calc...','Chargement d\'Impress...','Chargement de Draw, Base, Math...','NoteOffice V1 prêt !'];
let mi = 0;
const si = setInterval(() => { if (mi < splashMsgs.length) document.getElementById('sp-status').textContent = splashMsgs[mi++]; }, 380);
setTimeout(() => {
  clearInterval(si);
  const splash = document.getElementById('splash');
  splash.classList.add('hide');
  setTimeout(() => { splash.style.display = 'none'; document.getElementById('app').style.display = 'flex'; initAll(); }, 500);
}, 2500);

function initAll() { buildRibbon(); initCalc(); initImpress(); initBase(); }

// === APP NAVIGATION ===
const appTitles = { home:'Accueil — NoteOffice V1', write:'Sans titre — NoteOffice Write', calc:'Classeur1 — NoteOffice Calc', impress:'Présentation1 — NoteOffice Impress', draw:'Dessin1 — NoteOffice Draw', base:'Base1 — NoteOffice Base', math:'Formule — NoteOffice Math' };
const sbInfo = { home:'', write:'Document texte', calc:'Feuille de calcul', impress:'Présentation', draw:'Dessin vectoriel', base:'Base de données', math:'Éditeur de formules' };

function openApp(app) {
  currentApp = app;
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('show'));
  const sc = document.getElementById('screen-' + app);
  if (sc) sc.classList.add('show');
  document.querySelectorAll('.sidebar-item').forEach(s => s.classList.remove('active'));
  const si2 = document.getElementById('si-' + app);
  if (si2) si2.classList.add('active');
  document.getElementById('tb-filename').textContent = appTitles[app] || '';
  document.getElementById('sb-app').textContent = appTitles[app] || '';
  document.getElementById('sb-info').textContent = sbInfo[app] || '';
  if (app === 'draw') initDraw();
  buildRibbon();
}

// === RIBBON ===
const ribbonDefs = {
  accueil: {
    home: `<div class="rgroup"><div class="rbtns">
      <button class="rbtn" onclick="openApp('write')"><span class="icon">📄</span><span class="lbl">Write</span></button>
      <button class="rbtn" onclick="openApp('calc')"><span class="icon">📊</span><span class="lbl">Calc</span></button>
      <button class="rbtn" onclick="openApp('impress')"><span class="icon">📑</span><span class="lbl">Impress</span></button>
      <button class="rbtn" onclick="openApp('draw')"><span class="icon">🎨</span><span class="lbl">Draw</span></button>
      <button class="rbtn" onclick="openApp('base')"><span class="icon">🗄</span><span class="lbl">Base</span></button>
      <button class="rbtn" onclick="openApp('math')"><span class="icon">∑</span><span class="lbl">Math</span></button>
    </div><div class="rgroup-label">Applications</div></div>
    <div class="rgroup"><div class="rbtns">
      <button class="rbtn" onclick="newDoc()"><span class="icon">📄</span><span class="lbl">Nouveau</span></button>
      <button class="rbtn" onclick="openFileDialog()"><span class="icon">📂</span><span class="lbl">Ouvrir</span></button>
      <button class="rbtn" onclick="saveDoc()"><span class="icon">💾</span><span class="lbl">Enregistrer</span></button>
      <button class="rbtn"><span class="icon">🖨</span><span class="lbl">Imprimer</span></button>
    </div><div class="rgroup-label">Fichier</div></div>`,
    write: `<div class="rgroup"><div class="rbtns">
      <button class="rbtn" onclick="newDoc()"><span class="icon">📄</span><span class="lbl">Nouveau</span></button>
      <button class="rbtn" onclick="openFileDialog()"><span class="icon">📂</span><span class="lbl">Ouvrir</span></button>
      <button class="rbtn" onclick="saveDoc()"><span class="icon">💾</span><span class="lbl">Enregistrer</span></button>
      <button class="rbtn"><span class="icon">🖨</span><span class="lbl">Imprimer</span></button>
    </div><div class="rgroup-label">Fichier</div></div>
    <div class="rgroup"><div class="rbtns">
      <button class="rbtn rbtn-sm" onclick="cmd('bold')"><span class="icon"><b>G</b></span><span class="lbl">Gras</span></button>
      <button class="rbtn rbtn-sm" onclick="cmd('italic')"><span class="icon"><i>I</i></span><span class="lbl">Italique</span></button>
      <button class="rbtn rbtn-sm" onclick="cmd('underline')"><span class="icon"><u>S</u></span><span class="lbl">Souligné</span></button>
      <button class="rbtn rbtn-sm" onclick="cmd('strikeThrough')"><span class="icon"><s>T</s></span><span class="lbl">Barré</span></button>
    </div><div class="rgroup-label">Caractère</div></div>
    <div class="rgroup"><div class="rbtns">
      <button class="rbtn rbtn-sm" onclick="cmd('justifyLeft')"><span class="icon">◧</span><span class="lbl">Gauche</span></button>
      <button class="rbtn rbtn-sm" onclick="cmd('justifyCenter')"><span class="icon">▥</span><span class="lbl">Centre</span></button>
      <button class="rbtn rbtn-sm" onclick="cmd('justifyRight')"><span class="icon">◨</span><span class="lbl">Droite</span></button>
      <button class="rbtn rbtn-sm" onclick="cmd('justifyFull')"><span class="icon">▦</span><span class="lbl">Justifier</span></button>
    </div><div class="rgroup-label">Paragraphe</div></div>
    <div class="rgroup"><div class="rbtns">
      <button class="rbtn rbtn-sm" onclick="cmd('insertUnorderedList')"><span class="icon">≡</span><span class="lbl">Puces</span></button>
      <button class="rbtn rbtn-sm" onclick="cmd('insertOrderedList')"><span class="icon">⒈</span><span class="lbl">Numéros</span></button>
    </div><div class="rgroup-label">Listes</div></div>
    <div class="rgroup"><div class="rbtns">
      <button class="rbtn rbtn-sm" onclick="cmd('undo')"><span class="icon">↩</span><span class="lbl">Annuler</span></button>
      <button class="rbtn rbtn-sm" onclick="cmd('redo')"><span class="icon">↪</span><span class="lbl">Rétablir</span></button>
    </div><div class="rgroup-label">Historique</div></div>`,
    calc: `<div class="rgroup"><div class="rbtns">
      <button class="rbtn" onclick="newDoc()"><span class="icon">📊</span><span class="lbl">Nouveau</span></button>
      <button class="rbtn" onclick="saveDoc()"><span class="icon">💾</span><span class="lbl">Enregistrer</span></button>
    </div><div class="rgroup-label">Fichier</div></div>
    <div class="rgroup"><div class="rbtns">
      <button class="rbtn rbtn-sm"><span class="icon">∑</span><span class="lbl">Somme auto</span></button>
      <button class="rbtn rbtn-sm"><span class="icon">ƒ</span><span class="lbl">Fonction</span></button>
      <button class="rbtn rbtn-sm"><span class="icon">%</span><span class="lbl">Pourcent</span></button>
      <button class="rbtn rbtn-sm"><span class="icon">€</span><span class="lbl">Monétaire</span></button>
    </div><div class="rgroup-label">Formules</div></div>
    <div class="rgroup"><div class="rbtns">
      <button class="rbtn rbtn-sm"><span class="icon">📈</span><span class="lbl">Graphique</span></button>
      <button class="rbtn rbtn-sm"><span class="icon">🔃</span><span class="lbl">Trier</span></button>
      <button class="rbtn rbtn-sm"><span class="icon">🔍</span><span class="lbl">Filtrer</span></button>
    </div><div class="rgroup-label">Données</div></div>`,
    impress: `<div class="rgroup"><div class="rbtns">
      <button class="rbtn" onclick="addSlide()"><span class="icon">➕</span><span class="lbl">Nouvelle diapo</span></button>
      <button class="rbtn"><span class="icon">📋</span><span class="lbl">Dupliquer</span></button>
      <button class="rbtn"><span class="icon">🗑</span><span class="lbl">Supprimer</span></button>
    </div><div class="rgroup-label">Diapositives</div></div>
    <div class="rgroup"><div class="rbtns">
      <button class="rbtn"><span class="icon">▶</span><span class="lbl">Diaporama</span></button>
      <button class="rbtn"><span class="icon">🖥</span><span class="lbl">Plein écran</span></button>
    </div><div class="rgroup-label">Présenter</div></div>`,
    draw: `<div class="rgroup"><div class="rbtns">
      <button class="rbtn rbtn-sm" onclick="setTool('pencil')"><span class="icon">✏</span><span class="lbl">Crayon</span></button>
      <button class="rbtn rbtn-sm" onclick="setTool('line')"><span class="icon">╱</span><span class="lbl">Ligne</span></button>
      <button class="rbtn rbtn-sm" onclick="setTool('rect')"><span class="icon">▭</span><span class="lbl">Rect.</span></button>
      <button class="rbtn rbtn-sm" onclick="setTool('ellipse')"><span class="icon">○</span><span class="lbl">Ellipse</span></button>
      <button class="rbtn rbtn-sm" onclick="setTool('arrow')"><span class="icon">→</span><span class="lbl">Flèche</span></button>
    </div><div class="rgroup-label">Outils de dessin</div></div>
    <div class="rgroup"><div class="rbtns">
      <button class="rbtn rbtn-sm" onclick="undoDraw()"><span class="icon">↩</span><span class="lbl">Annuler</span></button>
      <button class="rbtn rbtn-sm" onclick="clearDraw()"><span class="icon">🗑</span><span class="lbl">Effacer</span></button>
      <button class="rbtn rbtn-sm" onclick="exportPNG()"><span class="icon">💾</span><span class="lbl">Exporter</span></button>
    </div><div class="rgroup-label">Actions</div></div>`,
    base: `<div class="rgroup"><div class="rbtns">
      <button class="rbtn rbtn-sm"><span class="icon">➕</span><span class="lbl">Ajouter</span></button>
      <button class="rbtn rbtn-sm"><span class="icon">✏</span><span class="lbl">Modifier</span></button>
      <button class="rbtn rbtn-sm"><span class="icon">🗑</span><span class="lbl">Supprimer</span></button>
    </div><div class="rgroup-label">Enregistrements</div></div>
    <div class="rgroup"><div class="rbtns">
      <button class="rbtn rbtn-sm"><span class="icon">🔍</span><span class="lbl">Rechercher</span></button>
      <button class="rbtn rbtn-sm"><span class="icon">🔃</span><span class="lbl">Trier</span></button>
      <button class="rbtn rbtn-sm"><span class="icon">📤</span><span class="lbl">Exporter</span></button>
    </div><div class="rgroup-label">Données</div></div>`,
    math: `<div class="rgroup"><div class="rbtns">
      <button class="rbtn rbtn-sm" onclick="ins('∑')"><span class="icon">∑</span><span class="lbl">Somme</span></button>
      <button class="rbtn rbtn-sm" onclick="ins('∫')"><span class="icon">∫</span><span class="lbl">Intégrale</span></button>
      <button class="rbtn rbtn-sm" onclick="ins('√')"><span class="icon">√</span><span class="lbl">Racine</span></button>
      <button class="rbtn rbtn-sm" onclick="ins('∞')"><span class="icon">∞</span><span class="lbl">Infini</span></button>
    </div><div class="rgroup-label">Symboles rapides</div></div>
    <div class="rgroup"><div class="rbtns">
      <button class="rbtn rbtn-sm" onclick="copyMath()"><span class="icon">📋</span><span class="lbl">Copier</span></button>
      <button class="rbtn rbtn-sm" onclick="insertInWrite()"><span class="icon">📄</span><span class="lbl">→ Write</span></button>
    </div><div class="rgroup-label">Actions</div></div>`
  }
};

function buildRibbon() {
  const app = currentApp === 'home' ? 'home' : currentApp;
  const tab = document.querySelector('.rtab.active')?.dataset.tab || 'accueil';
  const defs = ribbonDefs[tab] || ribbonDefs['accueil'];
  document.getElementById('ribbon').innerHTML = defs[app] || defs['home'] || '';
}

function switchTab(tab) {
  document.querySelectorAll('.rtab').forEach(t => t.classList.remove('active'));
  document.querySelector(`[data-tab="${tab}"]`).classList.add('active');
  buildRibbon();
}

// === WINDOW CONTROLS ===
function winMin() { ipcRenderer.send('window-minimize'); }
function winMax() { ipcRenderer.send('window-maximize'); }
function winClose() { ipcRenderer.send('window-close'); }

// === WRITE ===
function cmd(command, value) {
  document.getElementById('write-page')?.focus();
  document.execCommand(command, false, value || null);
  updateWordCount();
}
function updateWordCount() {
  const txt = document.getElementById('write-page')?.innerText || '';
  const words = txt.trim().split(/\s+/).filter(x => x.length > 0).length;
  document.getElementById('sb-words').textContent = `Mots : ${words}`;
}
document.getElementById('write-page')?.addEventListener('input', updateWordCount);
document.getElementById('write-page')?.addEventListener('keyup', e => {
  const sel = window.getSelection();
  if (sel && sel.rangeCount > 0) {
    const range = sel.getRangeAt(0);
    document.getElementById('sb-pos').textContent = `Ligne ${range.startOffset}`;
  }
});

function newDoc() {
  if (currentApp === 'write') {
    document.getElementById('write-page').innerHTML = '<h1 style="text-align:center;margin-bottom:20px;font-size:18pt">Sans titre</h1><p>Commencez à saisir votre document ici...</p>';
    document.getElementById('tb-filename').textContent = 'Sans titre — NoteOffice Write';
  }
  if (currentApp === 'calc') initCalc();
}

function saveDoc() {
  if (currentApp === 'write') {
    const html = document.getElementById('write-page').innerHTML;
    const blob = new Blob([`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Document NoteOffice</title></head><body>${html}</body></html>`], { type: 'text/html' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    a.download = 'document.html'; a.click();
  }
  showStatus('Document enregistré ✓', 2500);
}

function openFileDialog() { ipcRenderer.invoke('show-open-dialog', { properties: ['openFile'] }); }

function menuAction(action) {
  if (action === 'new') newDoc();
  if (action === 'save') saveDoc();
  if (action === 'open-write') openApp('write');
  if (action === 'open-calc') openApp('calc');
  if (action === 'open-impress') openApp('impress');
  if (action === 'open-draw') openApp('draw');
  if (action === 'open-base') openApp('base');
  if (action === 'open-math') openApp('math');
}
ipcRenderer.on('menu-action', (e, action) => menuAction(action));

// === CALC ===
const COLS = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P'];
const ROWS = 50;
let cellData = {};

function initCalc() {
  const tbl = document.getElementById('ssheet');
  let h = '<thead><tr><th style="width:36px"></th>';
  COLS.forEach(c => h += `<th id="ch-${c}">${c}</th>`);
  h += '</tr></thead><tbody>';
  for (let r = 1; r <= ROWS; r++) {
    h += `<tr><td class="rhdr">${r}</td>`;
    COLS.forEach(c => {
      h += `<td id="td-${c}${r}"><input type="text" id="c-${c}${r}" data-ref="${c}${r}"
        onfocus="selectCell('${c}${r}')"
        onblur="commitCell('${c}${r}')"
        onkeydown="navCell(event,'${c}',${r})"
        oninput="cellData['${c}${r}']=this.value"
      /></td>`;
    });
    h += '</tr>';
  }
  h += '</tbody>';
  tbl.innerHTML = h;
  // Sample data
  const sample = { A1:'Produit', B1:'Quantité', C1:'Prix unitaire', D1:'Total HT',
    A2:'Article A', B2:'10', C2:'25.00', D2:'=B2*C2',
    A3:'Article B', B3:'5', C3:'40.00', D3:'=B3*C3',
    A4:'Article C', B4:'20', C4:'12.50', D4:'=B4*C4',
    A5:'TOTAL', D5:'=D2+D3+D4' };
  Object.entries(sample).forEach(([ref, val]) => {
    const inp = document.getElementById('c-' + ref);
    if (inp) { inp.value = val; cellData[ref] = val; }
  });
  ['D2','D3','D4','D5'].forEach(r => evalCellRef(r));
}

function selectCell(ref) {
  document.getElementById('cellref').value = ref;
  document.getElementById('finput').value = cellData[ref] || '';
}

function commitCell(ref) {
  const val = document.getElementById('c-' + ref)?.value || '';
  cellData[ref] = val;
  if (val.startsWith('=')) evalCellRef(ref);
}

function evalCellRef(ref) {
  const val = cellData[ref] || '';
  if (!val.startsWith('=')) return;
  try {
    const expr = val.slice(1).replace(/([A-Z]+)(\d+)/g, (_, c, r) => {
      const v = parseFloat(cellData[c + r]);
      return isNaN(v) ? 0 : v;
    });
    const result = Function('"use strict"; return (' + expr + ')')();
    const inp = document.getElementById('c-' + ref);
    if (inp) inp.value = Math.round(result * 100) / 100;
  } catch(e) {
    const inp = document.getElementById('c-' + ref);
    if (inp) inp.value = '#ERR';
  }
}

function navCell(e, col, row) {
  const ci = COLS.indexOf(col);
  const keys = { Tab: [0,1], Enter: [1,0], ArrowRight: [0,1], ArrowLeft: [0,-1], ArrowDown: [1,0], ArrowUp: [-1,0] };
  const delta = keys[e.key];
  if (!delta) return;
  e.preventDefault();
  const nr = row + delta[0], nc = COLS[ci + delta[1]];
  if (nr >= 1 && nr <= ROWS && nc) document.getElementById('c-' + nc + nr)?.focus();
}

// === IMPRESS ===
let slides = [
  { title: 'Titre de la présentation', sub: 'Cliquez pour modifier le sous-titre', bg: '#fff' },
  { title: 'Deuxième diapositive', sub: 'Contenu ici', bg: '#fff' },
  { title: 'Troisième diapositive', sub: 'Votre message', bg: '#fff' }
];
let curSlide = 0;

function initImpress() { renderThumbs(); loadSlide(0); }

function renderThumbs() {
  const wrap = document.getElementById('im-thumbs');
  wrap.innerHTML = '';
  slides.forEach((s, i) => {
    const d = document.createElement('div');
    d.className = 'im-thumb' + (i === curSlide ? ' active' : '');
    d.style.background = s.bg || '#fff';
    d.innerHTML = `<div class="im-thumb-title" style="color:${s.bg && s.bg !== '#fff' && s.bg !== '#f1f5f9' ? '#fff' : '#334155'}">${s.title}</div><div class="im-thumb-num">${i + 1}</div>`;
    d.onclick = () => { curSlide = i; renderThumbs(); loadSlide(i); };
    wrap.appendChild(d);
  });
}

function loadSlide(i) {
  const s = slides[i];
  document.getElementById('active-slide').style.background = s.bg || '#fff';
  document.getElementById('slide-title').textContent = s.title;
  document.getElementById('slide-sub').textContent = s.sub;
  const isDark = s.bg && !['#fff','#f1f5f9','#ffffff'].includes(s.bg);
  document.getElementById('slide-title').style.color = isDark ? '#fff' : '#1e293b';
  document.getElementById('slide-sub').style.color = isDark ? 'rgba(255,255,255,.75)' : '#64748b';
}

function addSlide() {
  slides.splice(curSlide + 1, 0, { title: 'Nouvelle diapositive ' + (slides.length + 1), sub: 'Contenu', bg: '#fff' });
  curSlide++;
  renderThumbs(); loadSlide(curSlide);
}

function setBg(color) {
  slides[curSlide].bg = color;
  document.querySelectorAll('.cdot').forEach(d => d.classList.remove('active'));
  renderThumbs(); loadSlide(curSlide);
}

function setLayout(type) {
  document.querySelectorAll('.layout-opt').forEach(o => o.classList.remove('active'));
  event.target.classList.add('active');
  const sc = document.getElementById('slide-content');
  if (type === 'blank') { sc.innerHTML = ''; }
  else if (type === 'two-col') {
    sc.innerHTML = `<div style="display:flex;gap:20px;width:100%;height:100%">
      <div contenteditable="true" style="flex:1;border:1px dashed #e2e8f0;padding:12px;outline:none">Colonne gauche</div>
      <div contenteditable="true" style="flex:1;border:1px dashed #e2e8f0;padding:12px;outline:none">Colonne droite</div>
    </div>`;
  } else {
    sc.innerHTML = `<div class="slide-title" contenteditable="true" id="slide-title">${slides[curSlide].title}</div>
      <div class="slide-sub" contenteditable="true" id="slide-sub">${slides[curSlide].sub}</div>`;
  }
}

// === DRAW ===
let dTool = 'pencil', dColor = '#1e293b', dFill = '#dbeafe', dWidth = 2, dOpacity = 1, dDash = 'solid';
let dDrawing = false, dStartX = 0, dStartY = 0, dHistory = [], dSnapshot = null;
let dCtx = null, dCvs = null, gridOn = false;

function initDraw() {
  if (dCtx) return;
  dCvs = document.getElementById('drawCanvas');
  dCtx = dCvs.getContext('2d');
  dCtx.fillStyle = '#fff';
  dCtx.fillRect(0, 0, dCvs.width, dCvs.height);
  saveHistory();

  dCvs.onmousedown = e => {
    const r = dCvs.getBoundingClientRect();
    dStartX = e.clientX - r.left; dStartY = e.clientY - r.top;
    dDrawing = true;
    dSnapshot = dCtx.getImageData(0, 0, dCvs.width, dCvs.height);
    if (dTool === 'pencil') { dCtx.beginPath(); dCtx.moveTo(dStartX, dStartY); }
  };

  dCvs.onmousemove = e => {
    if (!dDrawing) return;
    const r = dCvs.getBoundingClientRect();
    const x = e.clientX - r.left, y = e.clientY - r.top;
    dCtx.globalAlpha = dOpacity;
    dCtx.strokeStyle = dColor;
    dCtx.fillStyle = dFill;
    dCtx.lineWidth = dWidth;
    dCtx.setLineDash(dDash === 'dash' ? [8,4] : dDash === 'dot' ? [2,4] : []);
    if (dTool === 'pencil') { dCtx.lineTo(x, y); dCtx.stroke(); return; }
    dCtx.putImageData(dSnapshot, 0, 0);
    dCtx.beginPath();
    if (dTool === 'line') { dCtx.moveTo(dStartX, dStartY); dCtx.lineTo(x, y); dCtx.stroke(); }
    else if (dTool === 'rect') { dCtx.rect(dStartX, dStartY, x - dStartX, y - dStartY); dCtx.fill(); dCtx.stroke(); }
    else if (dTool === 'ellipse') { dCtx.ellipse((dStartX+x)/2,(dStartY+y)/2,Math.abs(x-dStartX)/2,Math.abs(y-dStartY)/2,0,0,Math.PI*2); dCtx.fill(); dCtx.stroke(); }
    else if (dTool === 'triangle') { dCtx.moveTo((dStartX+x)/2,dStartY); dCtx.lineTo(x,y); dCtx.lineTo(dStartX,y); dCtx.closePath(); dCtx.fill(); dCtx.stroke(); }
    else if (dTool === 'arrow') {
      const angle = Math.atan2(y - dStartY, x - dStartX);
      dCtx.moveTo(dStartX, dStartY); dCtx.lineTo(x, y); dCtx.stroke();
      dCtx.beginPath();
      dCtx.moveTo(x, y);
      dCtx.lineTo(x - 15*Math.cos(angle-0.4), y - 15*Math.sin(angle-0.4));
      dCtx.lineTo(x - 15*Math.cos(angle+0.4), y - 15*Math.sin(angle+0.4));
      dCtx.closePath(); dCtx.fill();
    }
  };

  dCvs.onmouseup = () => { dDrawing = false; saveHistory(); };
}

function saveHistory() { if(dCtx) dHistory.push(dCtx.getImageData(0, 0, dCvs.width, dCvs.height)); }
function undoDraw() { if (dHistory.length > 1) { dHistory.pop(); dCtx.putImageData(dHistory[dHistory.length-1], 0, 0); } }
function clearDraw() { if (dCtx) { dCtx.fillStyle = '#fff'; dCtx.fillRect(0, 0, dCvs.width, dCvs.height); saveHistory(); } }
function exportPNG() {
  if (!dCvs) return;
  const a = document.createElement('a'); a.href = dCvs.toDataURL('image/png');
  a.download = 'dessin_noteoffice.png'; a.click();
}
function setTool(t) {
  dTool = t;
  document.querySelectorAll('.dt').forEach(d => d.classList.remove('active'));
  document.getElementById('dt-' + t)?.classList.add('active');
}
function toggleGrid(on) {
  gridOn = on;
  if (!dCtx) return;
  if (!on) { const img = dHistory[dHistory.length-1]; if(img) dCtx.putImageData(img,0,0); return; }
  const saved = dCtx.getImageData(0,0,dCvs.width,dCvs.height);
  dCtx.strokeStyle = 'rgba(100,116,139,.2)'; dCtx.lineWidth = 1; dCtx.setLineDash([]);
  for (let x = 0; x <= dCvs.width; x += 20) { dCtx.beginPath(); dCtx.moveTo(x,0); dCtx.lineTo(x,dCvs.height); dCtx.stroke(); }
  for (let y = 0; y <= dCvs.height; y += 20) { dCtx.beginPath(); dCtx.moveTo(0,y); dCtx.lineTo(dCvs.width,y); dCtx.stroke(); }
}
function insertShape(type) {
  if (!dCtx) { initDraw(); }
  const cx = dCvs.width/2, cy = dCvs.height/2;
  dCtx.globalAlpha = dOpacity; dCtx.strokeStyle = dColor; dCtx.fillStyle = dFill; dCtx.lineWidth = dWidth; dCtx.setLineDash([]);
  dCtx.beginPath();
  if (type === 'rect') { dCtx.rect(cx-60,cy-40,120,80); }
  else if (type === 'ellipse') { dCtx.ellipse(cx,cy,70,45,0,0,Math.PI*2); }
  else if (type === 'triangle') { dCtx.moveTo(cx,cy-50); dCtx.lineTo(cx+60,cy+40); dCtx.lineTo(cx-60,cy+40); dCtx.closePath(); }
  else if (type === 'diamond') { dCtx.moveTo(cx,cy-55); dCtx.lineTo(cx+55,cy); dCtx.lineTo(cx,cy+55); dCtx.lineTo(cx-55,cy); dCtx.closePath(); }
  else if (type === 'star') {
    for (let i = 0; i < 5; i++) {
      const a = Math.PI/180*(i*72-90), a2 = Math.PI/180*(i*72-90+36);
      if(i===0) dCtx.moveTo(cx+55*Math.cos(a),cy+55*Math.sin(a));
      else dCtx.lineTo(cx+55*Math.cos(a),cy+55*Math.sin(a));
      dCtx.lineTo(cx+22*Math.cos(a2),cy+22*Math.sin(a2));
    }
    dCtx.closePath();
  }
  else if (type === 'arrow-r') { dCtx.moveTo(cx-60,cy-10); dCtx.lineTo(cx+30,cy-10); dCtx.lineTo(cx+30,cy-25); dCtx.lineTo(cx+60,cy); dCtx.lineTo(cx+30,cy+25); dCtx.lineTo(cx+30,cy+10); dCtx.lineTo(cx-60,cy+10); dCtx.closePath(); }
  else if (type === 'arrow-d') { dCtx.moveTo(cx-10,cy-60); dCtx.lineTo(cx-10,cy+30); dCtx.lineTo(cx-25,cy+30); dCtx.lineTo(cx,cy+60); dCtx.lineTo(cx+25,cy+30); dCtx.lineTo(cx+10,cy+30); dCtx.lineTo(cx+10,cy-60); dCtx.closePath(); }
  else if (type === 'cloud') {
    dCtx.arc(cx-30,cy+10,25,Math.PI,0); dCtx.arc(cx-5,cy-10,30,Math.PI,0); dCtx.arc(cx+30,cy,20,Math.PI,0);
    dCtx.arc(cx+50,cy+20,15,0,Math.PI); dCtx.arc(cx,cy+30,50,0,Math.PI);
  }
  dCtx.fill(); dCtx.stroke();
  saveHistory();
}

// === BASE ===
const dbData = {
  clients: {
    headers: ['ID','Nom','Prénom','Email','Téléphone','Ville','Date inscription'],
    rows: [[1,'Martin','Jean','jean.martin@mail.fr','06 12 34 56 78','Paris','01/01/2024'],[2,'Dupont','Marie','m.dupont@mail.fr','07 23 45 67 89','Lyon','15/02/2024'],[3,'Bernard','Pierre','p.bernard@mail.fr','06 34 56 78 90','Marseille','10/03/2024'],[4,'Petit','Sophie','s.petit@mail.fr','07 45 67 89 01','Bordeaux','22/04/2024'],[5,'Robert','Lucas','l.robert@mail.fr','06 56 78 90 12','Toulouse','05/05/2024'],[6,'Moreau','Emma','e.moreau@mail.fr','07 67 89 01 23','Nantes','18/06/2024'],[7,'Simon','Thomas','t.simon@mail.fr','06 78 90 12 34','Strasbourg','30/07/2024']]
  },
  commandes: {
    headers: ['N° Cmd','Client','Produit','Quantité','Prix Total','Date','Statut'],
    rows: [[1001,'Martin J.','Produit A','3','75,00 €','12/03/2024','✅ Livré'],[1002,'Dupont M.','Produit B','1','120,00 €','13/03/2024','✅ Livré'],[1003,'Bernard P.','Produit C','5','250,00 €','14/03/2024','🚚 En cours'],[1004,'Petit S.','Produit A','2','50,00 €','15/03/2024','⏳ En attente'],[1005,'Robert L.','Produit D','8','400,00 €','16/03/2024','✅ Livré']]
  },
  produits: {
    headers: ['Réf.','Désignation','Catégorie','Prix HT','TVA','Prix TTC','Stock','Fournisseur'],
    rows: [['P001','Produit A','Catégorie 1','25,00 €','20%','30,00 €','150','Fournisseur X'],['P002','Produit B','Catégorie 2','120,00 €','20%','144,00 €','42','Fournisseur Y'],['P003','Produit C','Catégorie 1','50,00 €','20%','60,00 €','88','Fournisseur X'],['P004','Produit D','Catégorie 3','50,00 €','20%','60,00 €','200','Fournisseur Z']]
  },
  employes: {
    headers: ['ID','Nom','Prénom','Poste','Département','Salaire','Date embauche'],
    rows: [[1,'Lambert','Alice','Directrice','Direction','5500 €','01/01/2020'],[2,'Leroy','Marc','Dev Senior','Informatique','4200 €','15/03/2021'],[3,'Rousseau','Julie','Designer','Créatif','3600 €','01/06/2022'],[4,'Garnier','Paul','Commercial','Ventes','3200 €','10/09/2022']]
  }
};

function initBase() { loadTable('clients'); }
function loadTable(name) {
  document.querySelectorAll('.base-nav-item').forEach(i => i.classList.remove('active'));
  event?.target?.classList.add('active');
  const d = dbData[name];
  if (!d) return;
  let h = `<thead><tr>${d.headers.map(c => `<th>${c}</th>`).join('')}</tr></thead><tbody>`;
  d.rows.forEach(r => { h += `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`; });
  h += '</tbody>';
  document.getElementById('db-table').innerHTML = h;
}

// === MATH ===
function ins(sym) {
  const ta = document.getElementById('math-input');
  const p = ta.selectionStart;
  ta.value = ta.value.slice(0, p) + sym + ta.value.slice(p);
  ta.selectionStart = ta.selectionEnd = p + sym.length;
  updateMath();
}
function updateMath() { document.getElementById('math-preview').textContent = document.getElementById('math-input').value; }
function copyMath() { navigator.clipboard.writeText(document.getElementById('math-input').value).then(() => showStatus('Formule copiée ✓', 2000)); }
function clearMath() { document.getElementById('math-input').value = ''; updateMath(); }
function insertInWrite() {
  const f = document.getElementById('math-input').value;
  openApp('write');
  setTimeout(() => { document.getElementById('write-page').focus(); document.execCommand('insertText', false, ' ' + f + ' '); }, 100);
}

// === ZOOM ===
function changeZoom(delta) {
  zoom = Math.max(50, Math.min(200, zoom + delta));
  document.getElementById('sb-zoom').textContent = zoom + '%';
  const page = document.getElementById('write-page');
  if (page) { page.style.transform = `scale(${zoom/100})`; page.style.transformOrigin = 'top center'; }
}

// === STATUS ===
function showStatus(msg, duration = 3000) {
  const el = document.getElementById('sb-info');
  el.textContent = msg;
  setTimeout(() => { el.textContent = sbInfo[currentApp] || 'Prêt'; }, duration);
}

// === IPC from main ===
ipcRenderer.on('menu-action', (e, action) => menuAction(action));
