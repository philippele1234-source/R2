const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('noteoffice', {
  // Enregistrer un fichier
  saveFile: (options) => ipcRenderer.invoke('save-file', options),
  // Lire un fichier
  readFile: (filePath) => ipcRenderer.invoke('read-file', filePath),
  // Infos système
  getSystemInfo: () => ipcRenderer.invoke('get-system-info'),
  // Écouter les événements menu
  onMenu: (callback) => ipcRenderer.on('menu', (_, action) => callback(action)),
  // Écouter l'ouverture de fichier
  onFileOpened: (callback) => ipcRenderer.on('file-opened', (_, data) => callback(data)),
  // Retirer les listeners
  removeAllListeners: (channel) => ipcRenderer.removeAllListeners(channel)
});
