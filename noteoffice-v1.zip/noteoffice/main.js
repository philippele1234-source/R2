const { app, BrowserWindow, Menu, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');

let mainWindow;
const isDev = process.argv.includes('--dev');

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 900,
    minHeight: 600,
    title: 'NoteOffice V1',
    backgroundColor: '#f8fafc',
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      enableRemoteModule: true
    },
    show: false,
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default'
  });

  mainWindow.loadFile('src/index.html');

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    if (isDev) mainWindow.webContents.openDevTools();
  });

  mainWindow.on('closed', () => { mainWindow = null; });

  buildMenu();
}

function buildMenu() {
  const template = [
    {
      label: 'Fichier',
      submenu: [
        { label: 'Nouveau document',       accelerator: 'CmdOrCtrl+N', click: () => mainWindow.webContents.send('menu-action', 'new') },
        { label: 'Ouvrir…',                accelerator: 'CmdOrCtrl+O', click: openFile },
        { type: 'separator' },
        { label: 'Enregistrer',            accelerator: 'CmdOrCtrl+S', click: () => mainWindow.webContents.send('menu-action', 'save') },
        { label: 'Enregistrer sous…',      accelerator: 'CmdOrCtrl+Shift+S', click: saveFileAs },
        { type: 'separator' },
        { label: 'Exporter en PDF…',       click: () => mainWindow.webContents.send('menu-action', 'export-pdf') },
        { type: 'separator' },
        { label: 'Quitter',                accelerator: 'CmdOrCtrl+Q', click: () => app.quit() }
      ]
    },
    {
      label: 'Édition',
      submenu: [
        { label: 'Annuler',    accelerator: 'CmdOrCtrl+Z',       role: 'undo' },
        { label: 'Rétablir',   accelerator: 'CmdOrCtrl+Shift+Z', role: 'redo' },
        { type: 'separator' },
        { label: 'Couper',     accelerator: 'CmdOrCtrl+X',       role: 'cut' },
        { label: 'Copier',     accelerator: 'CmdOrCtrl+C',       role: 'copy' },
        { label: 'Coller',     accelerator: 'CmdOrCtrl+V',       role: 'paste' },
        { label: 'Tout sélectionner', accelerator: 'CmdOrCtrl+A', role: 'selectAll' },
        { type: 'separator' },
        { label: 'Rechercher…', accelerator: 'CmdOrCtrl+F', click: () => mainWindow.webContents.send('menu-action', 'find') }
      ]
    },
    {
      label: 'Affichage',
      submenu: [
        { label: 'Zoom avant',   accelerator: 'CmdOrCtrl+Plus',  click: () => mainWindow.webContents.send('menu-action', 'zoom-in') },
        { label: 'Zoom arrière', accelerator: 'CmdOrCtrl+-',     click: () => mainWindow.webContents.send('menu-action', 'zoom-out') },
        { label: 'Zoom 100%',    accelerator: 'CmdOrCtrl+0',     click: () => mainWindow.webContents.send('menu-action', 'zoom-reset') },
        { type: 'separator' },
        { label: 'Plein écran',  accelerator: 'F11', click: () => mainWindow.setFullScreen(!mainWindow.isFullScreen()) },
        { type: 'separator' },
        { label: 'Outils de développement', accelerator: 'F12', click: () => mainWindow.webContents.toggleDevTools() }
      ]
    },
    {
      label: 'Applications',
      submenu: [
        { label: '📄  Write',   click: () => mainWindow.webContents.send('menu-action', 'open-write') },
        { label: '📊  Calc',    click: () => mainWindow.webContents.send('menu-action', 'open-calc') },
        { label: '📑  Impress', click: () => mainWindow.webContents.send('menu-action', 'open-impress') },
        { label: '🎨  Draw',    click: () => mainWindow.webContents.send('menu-action', 'open-draw') },
        { label: '🗄️  Base',    click: () => mainWindow.webContents.send('menu-action', 'open-base') },
        { label: '∑  Math',     click: () => mainWindow.webContents.send('menu-action', 'open-math') }
      ]
    },
    {
      label: 'Aide',
      submenu: [
        { label: 'Documentation', click: () => shell.openExternal('https://noteoffice.github.io/docs') },
        { label: 'GitHub',        click: () => shell.openExternal('https://github.com/noteoffice/noteoffice-v1') },
        { type: 'separator' },
        { label: 'À propos de NoteOffice', click: showAbout }
      ]
    }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

async function openFile() {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Ouvrir un fichier',
    filters: [
      { name: 'Documents NoteOffice', extensions: ['odt','ods','odp','odg','odb'] },
      { name: 'Microsoft Office', extensions: ['docx','xlsx','pptx'] },
      { name: 'Tous les fichiers', extensions: ['*'] }
    ],
    properties: ['openFile']
  });
  if (!result.canceled && result.filePaths.length > 0) {
    const content = fs.readFileSync(result.filePaths[0], 'utf8');
    mainWindow.webContents.send('file-opened', { path: result.filePaths[0], content });
  }
}

async function saveFileAs() {
  const result = await dialog.showSaveDialog(mainWindow, {
    title: 'Enregistrer sous',
    defaultPath: 'Sans_titre.odt',
    filters: [
      { name: 'Document OpenDocument', extensions: ['odt'] },
      { name: 'Document Word', extensions: ['docx'] },
      { name: 'Fichier HTML', extensions: ['html'] },
      { name: 'Texte brut', extensions: ['txt'] }
    ]
  });
  if (!result.canceled) {
    mainWindow.webContents.send('file-save-as', result.filePath);
  }
}

function showAbout() {
  dialog.showMessageBox(mainWindow, {
    type: 'info',
    title: 'À propos de NoteOffice',
    message: 'NoteOffice V1',
    detail: 'Suite Bureautique Complète\nVersion 1.0.0\n\nGratuit et Open Source — Licence MIT\n© 2026 NoteOffice Project\n\nhttps://noteoffice.github.io',
    buttons: ['Fermer']
  });
}

// IPC handlers
ipcMain.handle('save-file', async (event, { filePath, content }) => {
  try { fs.writeFileSync(filePath, content, 'utf8'); return { success: true }; }
  catch (e) { return { success: false, error: e.message }; }
});

ipcMain.handle('read-file', async (event, filePath) => {
  try { return { success: true, content: fs.readFileSync(filePath, 'utf8') }; }
  catch (e) { return { success: false, error: e.message }; }
});

ipcMain.handle('show-save-dialog', async (event, options) => {
  return await dialog.showSaveDialog(mainWindow, options);
});

ipcMain.handle('show-open-dialog', async (event, options) => {
  return await dialog.showOpenDialog(mainWindow, options);
});

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
