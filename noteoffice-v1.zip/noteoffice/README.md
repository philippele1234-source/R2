# NoteOffice V1 — Suite Bureautique Complète

**Gratuit, Open Source, Multi-plateforme**

## Applications incluses
- **Write** — Traitement de texte (ODT, DOCX)
- **Calc** — Tableur avec formules (ODS, XLSX)
- **Impress** — Présentations (ODP, PPTX)
- **Draw** — Dessin vectoriel (ODG, SVG, PNG)
- **Base** — Base de données (ODB)
- **Math** — Éditeur de formules mathématiques

## Prérequis
- Node.js >= 18.x (https://nodejs.org)
- npm >= 9.x

## Installation & Lancement

```bash
# 1. Cloner ou extraire le projet
cd noteoffice-v1

# 2. Installer les dépendances
npm install

# 3. Lancer en mode développement
npm start
```

## Compiler l'application (.exe / .dmg / .AppImage)

```bash
# Windows (.exe installateur)
npm run build:win

# macOS (.dmg)
npm run build:mac

# Linux (.AppImage)
npm run build:linux

# Toutes les plateformes
npm run build:all
```

Les fichiers compilés seront dans le dossier `dist/`.

## Structure du projet

```
noteoffice-v1/
├── main.js              # Processus principal Electron
├── package.json         # Configuration npm + electron-builder
├── README.md
├── assets/
│   └── icons/           # Icônes app (icon.ico, icon.icns, icon.png)
└── src/
    ├── index.html       # Fenêtre principale (toutes les apps)
    ├── styles/
    │   └── global.css   # Styles globaux
    └── apps/
        └── shell.js     # Logique JS de toutes les applications
```

## Raccourcis clavier
| Raccourci | Action |
|-----------|--------|
| Ctrl+N | Nouveau document |
| Ctrl+O | Ouvrir |
| Ctrl+S | Enregistrer |
| Ctrl+Z | Annuler |
| Ctrl+B | Gras (Write) |
| Ctrl+I | Italique (Write) |
| Ctrl+U | Souligné (Write) |
| F11 | Plein écran |
| F12 | Outils développeur |

## Licence
MIT — © 2026 NoteOffice Project
